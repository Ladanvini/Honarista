#!/bin/bash
cd db
java -cp ../hsqldb.jar org.hsqldb.server.Server